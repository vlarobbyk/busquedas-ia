

public class RegexJava{

    private java.util.regex.Pattern pattern;
    private java.util.regex.Matcher matcher;
    private String fichero;
    
    public RegexJava(String fichero){
        this.fichero = fichero;
    }
    
    public boolean compilarRegex(String exp){
        try{
            pattern = java.util.regex.Pattern.compile(exp);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public void detectarRegex(){
        try{
            java.io.BufferedReader buffer = new java.io.BufferedReader(new java.io.FileReader(this.fichero));
            String linea = "";
            int pos=0;
            while((linea=buffer.readLine())!=null){
                //System.out.println(linea);
                matcher = pattern.matcher(linea);
                pos = 0;
                while(matcher.find(pos)){
                    System.out.println("Encontro Patron Regular: "+matcher.start()+"|"+matcher.end()+"=>"+matcher.group());
                    pos = matcher.end()+1;
                }
            }
            buffer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public class Patron{
        public String cadena;
        public int inicio;
        public int fin;
    }
    
    
    public static void main(String [] args){
        String expr = "(\\s+)[1-9][0-9]+(\\s+)";
        System.out.println(expr);
        RegexJava reg = new RegexJava("FicheroDatos.txt");
        boolean r = reg.compilarRegex(expr);
        System.out.println("Res: "+r);
        
        reg.detectarRegex();
    }
    
}